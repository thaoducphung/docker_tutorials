## The code for these demos has been put into their own repositories to make it easier to keep them up-to-date.

ASP.NET Core Demo: https://github.com/DanWahlin/AspNetCorePostgreSQLDockerApp

Node.js Demo: https://github.com/DanWahlin/NodeExpressMongoDBDockerApp